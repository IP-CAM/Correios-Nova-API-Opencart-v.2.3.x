<?php
// Heading
$_['heading_title']      = 'Correios Online e Offline PRO [Loja5]';

// Text
$_['text_shipping']    = 'Envio';
$_['text_success']     = 'Dados salvos com sucesso!';

// Entry
$_['entry_geo_zone']   = 'Zona de Envio:';
$_['entry_status']     = 'Status:';
$_['entry_sort_order'] = 'Ordem:';

?>
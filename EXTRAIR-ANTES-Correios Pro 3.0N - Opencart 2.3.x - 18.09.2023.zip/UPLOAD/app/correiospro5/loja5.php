<?php 
/*
Modulo Comercial - Loja5.com.br
Proibido vender, revender ou distribuir o mesmo sem a devida licenca de uso de acordo os termos da lei 9.609/98 e numero 9.610/98, que protegem o direito de autor sobre programas de computador.
https://www.loja5.com.br/termos-de-compra-suporte-loja5-i5.html
*/
if(!function_exists("dec5licloja5")){
	function dec5licloja5($string){
		eval($string);
	}
}
?>